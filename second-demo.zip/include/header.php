<header class="stricky">
	<nav class=" navbar navbar navbar-expand-lg  " arial-label="Furni navigation bar">

		<div class="navbar-inner containerFull navbar-inner  w-100">
			<a class="navbar-brand" href="index.html">
				<img src="images/logo.png" alt="">
			</a>

			<button class="navbar-toggler collapsed" type="button" data-bs-toggle="collapse"
				data-bs-target="#navbarsbloom" aria-controls="navbarsbloom" aria-expanded="false"
				aria-label="Toggle navigation">
				<span class="navbar-toggler-icon"></span>
			</button>

			<div class="navbar-collapse collapse" id="navbarsbloom" style="">
				<ul class="custom-navbar-nav navbar-nav ms-auto mb-2 mb-md-0">
					<li class="nav-item">
						<a class="nav-link" href="index.html">Home</a>
					</li>
					<li><a class="nav-link" href="about.html">About us</a></li>
					<li><a class="nav-link" href="services.html">Services</a></li>
					<li><a class="nav-link" href="blog.html">Gallery</a></li>
					<li><a class="nav-link" href="blog.html">Blog</a></li>
					<li class="active"><a class="nav-link" href="contact.html">Contact us</a></li>
				</ul>

				<ul class="custom-navbar-cta navbar-nav mb-2 mb-md-0 ms-5 d-none d-lg-block">
					<a class="btn_1 " href="#">
						Let's Connect
					</a>
				</ul>
			</div>
		</div>

	</nav>
</header>